package com.vizsgaremek.backend.service;

import com.vizsgaremek.backend.dto.request.CreateUserRequest;
import com.vizsgaremek.backend.dto.request.UpdateUserRequest;
import com.vizsgaremek.backend.dto.response.UserResponse;
import com.vizsgaremek.backend.repository.UserRepository;
import jakarta.validation.Valid;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
}

